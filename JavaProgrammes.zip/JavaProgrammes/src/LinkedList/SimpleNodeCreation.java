/*
package LinkedList;

import javax.xml.soap.Node;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.management.BufferPoolMXBean;

class SimpleNodeCreation {


    public static void main(String[] args) {
        int choice = 0;
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

        LinkedList list = new LinkedList();
        LinkedList.Node first = new LinkedList.Node(1);
        LinkedList.Node second = new LinkedList.Node(2);
        LinkedList.Node third = new LinkedList.Node(3);
        LinkedList.Node firstNode = new LinkedList.Node(0);
        LinkedList.Node lastNode = new LinkedList.Node(4);
        LinkedList.Node x = new LinkedList.Node(5);

        list.head = first;
        first.next = second;
        second.next = third;

        while (true) {
            System.out.print("choose 1 : To add new element at front \n" +
                    "2: To add node in the last \n" +
                    "3: To add node anywhere in the list\n" +
                    "4: To add node at the given Node \n" +
                    "5: To dele any node\n");


            try {
                choice = Integer.parseInt(bufferedReader.readLine());
            } catch (IOException e) {
                e.printStackTrace();
            }

            switch (choice) {

                case 1:
                    list.addElement(firstNode, 0);
                    list.printList(list);
                    break;


                case 2:
                    list.addElementToTheLast(lastNode, 4);
                    list.printList(list);
                    break;


                case 3:
                    list.addElementInBetweenTheList(6, x);
                    list.printList(list);
                    break;


                case 4:
                    list.addElementByGivenNode(second, x);
                    list.printList(list);
                    break;

                case 5:
                    list.deleteNode(x);
                    list.printList(list);
                    break;

                case 6:
                    System.exit(0);

            }


        }

    }

}*/
