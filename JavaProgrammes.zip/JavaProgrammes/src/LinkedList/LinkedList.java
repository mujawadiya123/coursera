package LinkedList;


public class  LinkedList {
    Node head;

    static class Node {

        int data;
        Node next;

        Node(int d) {

            this.data = d;
            this.next = null;


        }

    }

    public void printList() {

        Node temp = head;
        while (true) {
            if (temp == null)
                break;

            System.out.println(
                    temp.data);
            temp = temp.next;

        }
    }

    public void addElement(Node newNode, int data) {
        newNode.next = head;
        head = newNode;


    }

    public void addElementByGivenNode(Node prev_Node, Node new_Node) {

        if (prev_Node == null) {

            try {
                throw new Exception("previousNode cannot be null");
            } catch (Exception e) {
                e.printStackTrace();
            }
            System.exit(0);
        } else {
            new_Node.next = prev_Node.next;
            prev_Node.next = new_Node;

        }

    }

    public void addElementToTheLast(Node newNode, int data) {

        Node temp = head;
        if (temp == null) {

            temp = newNode;
        }

        while (temp != null) {

            if (temp.next == null) {

                temp.next = newNode;
                break;
            } else {

                temp = temp.next;

            }

        }
    }

    public void addElementInBetweenTheList(int position, Node newNode) {

        Node temp = head;
        int count = 1;

        // case:1
        if (head == null) {

            if (position == 0) {
                head = newNode;
            } else {

                System.out.println("Invalid insertion request");
            }

        }
        // case : 2

        if (position == 0) {

            newNode.next = head;
            head = newNode;
            return;
        }
        // case : 3
        if (position != 0) {
            while (true) {

                if (count == position) {


                    if (temp.next == null) {

                        temp.next = newNode;
                        newNode.next = null;
                        break;
                    }


                    newNode.next = temp.next;
                    temp.next = newNode;
                    break;
                } else {

                    count++;
                    temp = temp.next;

                    if (temp == null) {

                        try {
                            throw new Exception("Invalid Rrquest");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        System.exit(0);

                    }
                }


            }


        } else {

            try {
                throw new Exception("Invalid Rrquest");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    public void deleteNode(Node node_to_be_deleted) {


        Node prev_node = head;
        Node next_Node = head;

        //case: 1


        if (head == node_to_be_deleted) {

            if (head.next == null) {

                head = null;
            } else {
                head = head.next;
                return;

            }

            while (true) {


                if (prev_node.next == null) {

                    try {
                        throw new Exception("This node does not exist");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    System.exit(0);
                }

                next_Node = next_Node.next;

                if (next_Node == node_to_be_deleted) {

                    if (next_Node.next == null) {

                        prev_node.next = null;
                        break;

                    }

                    prev_node.next = next_Node.next;
                    next_Node.next = null;

                    break;

                }

                prev_node = prev_node.next;

            }


        }
    }

    public void deleteNode2(Node del) {
        Node temp = head;

   /* if (head.next == null){

        if(head==del){

            head= null;
            return;
        }
    }


    while (temp.next!= null){

        if(head == del){

            head = head.next;

            break;

        }

        if (temp.next== del){

            temp.next= temp.next.next;
            break;
            }


            temp = temp.next;

    }*/

        if (head != null && head == del) {

            head = head.next;
            return;
        }

        while (temp != null) {


            if (temp.next == del) {
                temp.next = temp.next.next;
                break;

            }
            if (temp.next == null) {

                System.out.println("index out od bound");
                break;
            }
            temp = temp.next;
        }


    }

    void deleteNodeBYKey(int key) {
        // Store head node
        Node temp = head, prev = null;


        // If head node itself holds the key to be deleted
        if (temp != null && temp.data == key) {
            head = temp.next; // Changed head
            return;
        }

        // Search for the key to be deleted, keep track of the
        // previous node as we need to change temp.next
        while (temp != null && temp.data != key) {
            prev = temp;
            temp = temp.next;
        }

        // If key was not present in linked list
        if (temp == null) {
            System.out.println("invalid");
            return;
        }
        // Unlink the node from linked list
        prev.next = temp.next;
    }

    public void deleteANodeByPOsition(int position) {
        Node temp = head, prev;
        int count = 1;

        // case:1

        if (head != null && position == 0) {

            head = head.next;
            return;
        }

        while (position != 0 && temp != null) {

            prev = temp;
            temp = temp.next;

            if (position == count) {
// bug i want to show to ricky
                prev = temp.next;
                temp.next = null;

                break;
            }

            if (temp == null) {

                System.out.print("Index out of bound");
                return;
            }

            count++;


        }


    }

    public void deletionUsingForLoop(int position) {

        Node temp = head;

        if (position == 0) {

            head = head.next;

        }
        for (int i = 1; temp != null && i < position; i++) {

            temp = temp.next;
        }
        if (temp == null) {


            System.out.println("invalid position value");
            return;
        }

        Node next = temp.next.next;
        temp.next = next;
    }

    public void deleteLinkedList() {

        for (int i = 0; head != null; i++) {
            System.out.println("deleted");
            head = head.next;

        }

        head = null;


    }

    public void lengthOfALinkedlist() {
        Node temp = head;
        int i;
        //case: 1

        if (head == null) {

            System.out.println("list is empty :" + 0);
            return;
        }

        for (i = 0; temp != null; i++) {

            temp = temp.next;
        }
        System.out.println("length is:" + i);
    }

    public int lengthOfALinkedListRecursion(Node node) {

        Node temp = head;

        if (temp == null) {

            return 0;
        }

        return 1 + lengthOfALinkedListRecursion(temp.next);
    }


    public int getCountRecursion() {
        Node temp = head;
        return lengthOfALinkedListRecursion(temp);
    }


    public boolean searchElementThroughRecursion(Node head, int key) {

        Node temp = head;
        if (temp == null) {

            return false;
        }

        if (temp.data == key) {

            return true;
        }
        return searchElementThroughRecursion(temp.next, key);

    }

    public boolean searchElementByIteration( int key) {
        Node temp = head;

        for (int i = 0; temp != null; i++) {

            if (key == temp.data) {
                return true;
            } else {

                temp = temp.next;
            }

        }


     return  false;
    }

    

}