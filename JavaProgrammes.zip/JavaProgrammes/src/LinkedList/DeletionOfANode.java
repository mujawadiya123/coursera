package LinkedList;

import java.io.BufferedReader;
import java.io.InputStreamReader;






import javax.xml.soap.Node;
        import java.io.BufferedReader;
        import java.io.IOException;
        import java.io.InputStreamReader;
        import java.lang.management.BufferPoolMXBean;


public class DeletionOfANode {

    public static void main(String[] args) {
        int choice = 0;
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

        LinkedList list = new LinkedList();
        LinkedList.Node first = new LinkedList.Node(1);
        LinkedList.Node second = new LinkedList.Node(2);
        LinkedList.Node third = new LinkedList.Node(3);
        LinkedList.Node firstNode = new LinkedList.Node(0);
        LinkedList.Node lastNode = new LinkedList.Node(4);
        LinkedList.Node x = new LinkedList.Node(5);

        list.head = first;
        first.next = second;
        second.next = third;

     //    list.deleteNode2(first);
       // list.deleteNodeBYKey(4);
      //list.deleteANodeByPOsition(0);
      //  list.deletionUsingForLoop(3);
    //    list.deleteLinkedList();

      //  list.lengthOfALinkedlist();
     // int y= list.getCountRecursion();
      //  System.out.println(y);
    //   Boolean b= list.searchElementThroughRecursion(first,5);
        Boolean b1 = list.searchElementByIteration(7);
        System.out.println(b1);
        list.printList();

    }

}