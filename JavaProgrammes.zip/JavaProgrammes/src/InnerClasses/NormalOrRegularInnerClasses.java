package InnerClasses;

public class NormalOrRegularInnerClasses {




    class InnerClass{

        public void m1(){

            System.out.print("hii");
        }
    }
    public  static  void main(String[] args){

     //   NormalOrRegularInnerClasses.InnerClass i= new NormalOrRegularInnerClasses().new InnerClass();
      //  i.m1();
        System.out.print("i");
    }


}
