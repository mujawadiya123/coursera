package InnerClasses;
import java.awt.*;
import  java.awt.event.*;

public class GUIExample {
    public  static void main(String args[]){


        Frame f = new Frame();
        f.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {

for(int i = 0; i<=10 ; i++){

    System.out.print("hii");
    System.exit(0);
}

            }
        });

    }
}
