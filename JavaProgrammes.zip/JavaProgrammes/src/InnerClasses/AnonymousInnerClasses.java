package InnerClasses;

class Porpcorn{

    public void taste (){

        System.out.print("spicy");
    }
    //100 more methods
}


public class AnonymousInnerClasses {


    public static void main(String[] args){

        Porpcorn p = new Porpcorn()
        {
          public  void taste(){

              System.out.print("salty");
          }
        };
   p.taste();
   Porpcorn p1 = new Porpcorn();
   p1.taste();
        System.out.print(p.getClass().getName());

    }

}
