package InnerClasses;

public class FromOuterClass {

    class innerClass {

        public void m1() {

            System.out.print("hii");


        }


    }
}

class Outer {

    public static void main(String[] args) {


        FromOuterClass.innerClass i = new FromOuterClass().new innerClass();
        i.m1();
    }


}
