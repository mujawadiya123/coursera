package InnerClasses;

public class AccessingInnerClassFromOuterInstanceArea {


    class InnerClass{

        public void m1(){

            System.out.print("hii");
        }
    }
public  void m2(){
         InnerClass i = new InnerClass();
         i.m1();
        System.out.print("hello");

}
public  static  void main(String[] args){


    AccessingInnerClassFromOuterInstanceArea i = new AccessingInnerClassFromOuterInstanceArea();
    i.m2();


}
}


