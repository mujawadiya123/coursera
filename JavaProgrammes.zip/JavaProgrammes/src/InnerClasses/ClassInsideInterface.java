package InnerClasses;

import java.util.ArrayList;

public class ClassInsideInterface {

    public static void main(String[] args) {
        ArrayList<?> l = new ArrayList<String>();
        l.add(null);
    }



}
class VehicalTypes{


}