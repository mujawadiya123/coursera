package InnerClasses;

public class StaticNestedInnerClasses {
    int x= 10;
    static int y = 20;
    
    static  class Nested{

        public  void m1(){

          //  System.out.println(x);// cannot be accesed
            System.out.println(y);
        }
    }

    public static void main(String[] args) {
        Nested n = new Nested();
        n.m1();
        StaticNestedInnerClasses s = new StaticNestedInnerClasses();
        int x=s.x;
    }
}
