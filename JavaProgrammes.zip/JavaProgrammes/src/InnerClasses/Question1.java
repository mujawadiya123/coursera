package InnerClasses;

public class Question1 {
    int i = 0;
    static int j=10;
    public  void m1(){
        int k=20;
      final int m=30;
        class InnerClass{

            public void m2(){
                System.out.println(i+" "+j+" "+k+" "+m);
                System.out.println(k);
            }

        }
      InnerClass i = new InnerClass();
        i.m2();


    }
    public static  void main(String[] args){

        Question1 q = new Question1();
        q.m1();
    }
}
