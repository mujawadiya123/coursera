package InnerClasses;

public class RunnableInterfaceEx {


   public  static void  main(String[] args){

        new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.print("c");

            }
        }).start();
       System.out.println("m");
    }
}
