package InnerClasses;

public class AccesingStaticVariable {

    int x = 10;
    static int y = 20;
public  void m2(){
    class InnerClass {
        int x = 1000;


        public void m1() {
            int x = 100;

            System.out.print(x);
            System.out.print(y);
            System.out.print(this.x);
            System.out.print(AccesingStaticVariable.this.x);

        }
    }
InnerClass i = new InnerClass();
            i.m1();
        }

        public static void main(String[] args) {


           AccesingStaticVariable i = new AccesingStaticVariable();
           i.m2();
        }
    }
