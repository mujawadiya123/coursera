package example;

import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeSet;

public class CopyOnWriteArraySet {

    public static void main(String[] args) {

        java.util.concurrent.CopyOnWriteArraySet c1 = new java.util.concurrent.CopyOnWriteArraySet();
       /* c.add("a");
        c.add(null);
        c.add(null);*/


        TreeSet c = new TreeSet();

        c.add(null);
     //   c.add(null);
        System.out.print(c);
    }
}
