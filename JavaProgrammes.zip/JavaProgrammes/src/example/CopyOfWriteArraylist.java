package example;

import java.util.ArrayList;
import java.util.ListIterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOfWriteArraylist {

    public static void main (String args[]){
        ArrayList l = new ArrayList();
        l.add("A");
        l.add("B");
        CopyOnWriteArrayList l2 = new CopyOnWriteArrayList();
        l2.add("A");
        l2.add("c");
        ListIterator itr = l2.listIterator();
        l2.add("e");
        while (itr.hasNext()){

            String s = (String)itr.next();
            System.out.print(s);

        }

CopyOnWriteArrayList c = new CopyOnWriteArrayList();
l2.addAllAbsent(l);

    }
}