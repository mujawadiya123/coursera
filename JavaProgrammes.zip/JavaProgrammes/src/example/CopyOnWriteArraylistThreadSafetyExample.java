package example;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

 public class CopyOnWriteArraylistThreadSafetyExample extends Thread {
   static CopyOnWriteArrayList list = new CopyOnWriteArrayList();


     public  void run(){

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();

        }
list.addIfAbsent("a");


    }


}

class Main{

     public  static  void main(String[] args){



         CopyOnWriteArraylistThreadSafetyExample.list.add("A");
         CopyOnWriteArraylistThreadSafetyExample.list.add("b");
CopyOnWriteArraylistThreadSafetyExample c= new CopyOnWriteArraylistThreadSafetyExample();
c.start();

        Iterator t= CopyOnWriteArraylistThreadSafetyExample.list.iterator();
        while(t.hasNext()){
String s = (String)t.next();
if(s.equals("b")){

    t.remove();
}
            System.out.print(s);
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

     }

}